## Playlists category: global


|   Name         | Playlist
|  :-----------: | :-------
|   exo00        | `https://raw.githubusercontent.com/devsground/IPTV/master/2020/exo/exo_all.m3u`
|   alternate    | `https://bit.ly/exoall00`


|   Name         | Playlist                               | Short
|  :-----------: | :-------                               | :-------
|   exo01        | `https://pastebin.com/raw/VKVYwA19`    |
|   exo02        | `https://pastebin.com/raw/vsHdbBCa`    |
|   exo03        | `https://pastebin.com/raw/JVw49ger`    |


## Supported applications:

Choose any of the IPTV player
https://play.google.com/store/apps/dev?id=7053436804067704459

or Search IPTV Lite - HD IPTV Player on playstore

## Notice
If you just found an error or have any suggestions on how to organize a playlist please send a mail to us (devsground.help@gmail.com)
