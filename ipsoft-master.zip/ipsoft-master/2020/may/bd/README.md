## Playlists category: bdix

| Name          | Playlist                               | Short
| :-----------: | :-------                               | :-------
|   bd01        | `https://pastebin.com/raw/jKr2rjCR`    | `https://bit.ly/bdixbd01`
|   bd02        | `https://pastebin.com/raw/FAnTC1tB`    | `https://bit.ly/bdixbd02`
|   bd03        | `https://pastebin.com/raw/RUEstVpv`    | `https://bit.ly/bdixbd03`
|   bd04        | `https://pastebin.com/raw/snAU6Q5B`    | `https://bit.ly/bdixbd04`
|   bd05 (new)  | `https://pastebin.com/raw/GTfL1bcj`    | `https://bit.ly/bdixbd05`
|   bd06 (new)  | `https://pastebin.com/raw/b1TttLJg`    | `https://bit.ly/bdixbd06`



## Supported applications:

Choose any of the IPTV player
https://play.google.com/store/apps/dev?id=7053436804067704459

or Search IPTV Lite - HD IPTV Player on playstore

## Notice
If you just found an error or have any suggestions on how to organize a playlist please send a mail to us (devsground.help@gmail.com)
